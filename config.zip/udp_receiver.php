<?php

// $serverIp = '127.0.0.1';  // Change this to your Laravel server's IP address
// $serverPort = 8000;      // Change this to the Laravel server's port

// $socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);

// if (!$socket) {
//     die('Unable to create socket');
// }

// if (!socket_bind($socket, $serverIp, $serverPort)) {
//     die('Unable to bind socket');
// }

// while (true) {
//     $data = socket_recvfrom($socket, $buffer, 1024, 0, $clientIp, $clientPort);

//     if ($data === false) {
//         die('Error receiving data');
//     }

//     $url = "http://$serverIp:$serverPort/receive-nmea";
//     $dataToSend = ['nmea_data' => $buffer];

//     $options = [
//         'http' => [
//             'method' => 'POST',
//             'header' => 'Content-Type: application/x-www-form-urlencoded',
//             'content' => http_build_query($dataToSend),
//         ],
//     ];

//     $context = stream_context_create($options);
//     $result = file_get_contents($url, false, $context);

//     if ($result === false) {
//         die('Error sending data to Laravel');
//     }

//     echo "Sent data: $buffer\n";
// }
