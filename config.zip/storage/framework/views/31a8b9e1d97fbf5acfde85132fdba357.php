<!DOCTYPE html>
<html>
<head>
    <title>NMEA Data Receiver</title>
</head>
<body>
    <h1>NMEA Data Receiver</h1>
    <p>Received NMEA data:</p>
    <pre><?php echo e($nmeaData); ?></pre>
</body>
</html><?php /**PATH C:\laragon\www\Api_Pemantau_Kapal\resources\views/nmea.blade.php ENDPATH**/ ?>