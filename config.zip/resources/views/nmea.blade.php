<!DOCTYPE html>
<html>
<head>
    <title>NMEA Data Receiver</title>
</head>
<body>
    <h1>NMEA Data Receiver</h1>
    <p>Received NMEA data:</p>
    <pre>{{ $nmeaData }}</pre>
</body>
</html>